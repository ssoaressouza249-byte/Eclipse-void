package com.example.shizuku

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.example.data.ShizukuStatus
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

class ShizukuEngine(private val context: Context) {

  data class ShellResult(val success: Boolean, val exitCode: Int, val output: String)

  private val _status = MutableStateFlow(ShizukuStatus.BINDER_DEAD)
  val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

  private var listenersRegistered = false

  private val binderReceivedListener = Shizuku.OnBinderReceivedListener { refreshStatus() }

  private val binderDeadListener = Shizuku.OnBinderDeadListener { refreshStatus() }

  private val permissionResultListener =
    Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
      if (requestCode == SHIZUKU_REQUEST_CODE) {
        refreshStatus()
      }
    }

  fun startListening() {
    runCatching {
      if (!listenersRegistered) {
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        listenersRegistered = true
      }
    }
    refreshStatus()
  }

  fun stopListening() {
    runCatching {
      if (listenersRegistered) {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        listenersRegistered = false
      }
    }
  }

  fun isShizukuAppInstalled(): Boolean {
    return runCatching {
        context.packageManager.getPackageInfo(SHIZUKU_MANAGER_PACKAGE, 0)
        true
      }
      .getOrDefault(false)
  }

  fun refreshStatus(): ShizukuStatus {
    val computed =
      runCatching {
          val installed = isShizukuAppInstalled()
          val binderAlive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
          when {
            !binderAlive && !installed -> ShizukuStatus.NOT_INSTALLED
            !binderAlive -> ShizukuStatus.BINDER_DEAD
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED ->
              ShizukuStatus.PERMISSION_REQUIRED
            else -> ShizukuStatus.READY
          }
        }
        .getOrDefault(ShizukuStatus.BINDER_DEAD)
    _status.value = computed
    return computed
  }

  fun requestPermissionOrOpenShizuku(): String? {
    val current = refreshStatus()
    return when (current) {
      ShizukuStatus.READY -> null
      ShizukuStatus.PERMISSION_REQUIRED -> {
        val requested =
          runCatching {
              Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
              true
            }
            .getOrDefault(false)
        if (requested) null else "Não foi possível solicitar permissão ao Shizuku."
      }
      ShizukuStatus.BINDER_DEAD -> {
        openShizukuManager()
        "Inicie o serviço Shizuku no app Shizuku e volte aqui."
      }
      ShizukuStatus.NOT_INSTALLED -> {
        "Instale e ative o Shizuku (moe.shizuku.privileged.api) para executar comandos."
      }
    }
  }

  fun openShizukuManager(): Boolean {
    return runCatching {
        val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_MANAGER_PACKAGE)
        if (intent != null) {
          intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          context.startActivity(intent)
          true
        } else {
          false
        }
      }
      .getOrDefault(false)
  }

  suspend fun clearCacheAndUninstallKeepData(packageName: String): ShellResult =
    withContext(Dispatchers.IO) {
      val currentStatus = refreshStatus()
      if (currentStatus != ShizukuStatus.READY) {
        return@withContext ShellResult(
          success = false,
          exitCode = -1,
          output = statusErrorMessage(currentStatus),
        )
      }

      // Best-effort cache cleanup before uninstalling for user 0
      runCatching {
        executeShellCommand("pm clear --cache-only $packageName")
        executeShellCommand("rm -rf /sdcard/Android/data/$packageName/cache")
      }

      val uninstallResult = executeShellCommand("pm uninstall -k --user 0 $packageName")
      val succeeded =
        uninstallResult.exitCode == 0 ||
          uninstallResult.output.contains("Success", ignoreCase = true)

      uninstallResult.copy(success = succeeded)
    }

  suspend fun restoreExistingPackage(packageName: String): ShellResult =
    withContext(Dispatchers.IO) {
      val currentStatus = refreshStatus()
      if (currentStatus != ShizukuStatus.READY) {
        return@withContext ShellResult(
          success = false,
          exitCode = -1,
          output = statusErrorMessage(currentStatus),
        )
      }

      val primary = executeShellCommand("cmd package install-existing $packageName")
      val primaryOk =
        primary.exitCode == 0 ||
          primary.output.contains("installed for user", ignoreCase = true) ||
          primary.output.contains("Package $packageName", ignoreCase = true)

      if (primaryOk) {
        return@withContext primary.copy(success = true)
      }

      val fallback = executeShellCommand("cmd package install-existing --user 0 $packageName")
      val fallbackOk =
        fallback.exitCode == 0 ||
          fallback.output.contains("installed for user", ignoreCase = true) ||
          fallback.output.contains("Package $packageName", ignoreCase = true)

      fallback.copy(success = fallbackOk)
    }

  private fun executeShellCommand(command: String): ShellResult {
    return runCatching {
        val process = startShizukuProcess(arrayOf("sh", "-c", command))
          ?: return ShellResult(
            success = false,
            exitCode = -1,
            output = "Falha ao abrir processo privilegiado via Shizuku.",
          )

        val outputBuilder = StringBuilder()
        runCatching {
          BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
            var line: String?
            while (reader.readLine().also { line = it } != null) {
              outputBuilder.appendLine(line)
            }
          }
        }
        runCatching {
          BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
            var line: String?
            while (reader.readLine().also { line = it } != null) {
              outputBuilder.appendLine(line)
            }
          }
        }

        val exitCode = process.waitFor()
        runCatching { process.destroy() }
        ShellResult(
          success = exitCode == 0,
          exitCode = exitCode,
          output = outputBuilder.toString().trim(),
        )
      }
      .getOrElse { error ->
        ShellResult(
          success = false,
          exitCode = -1,
          output = error.message ?: "Erro desconhecido ao executar comando Shizuku.",
        )
      }
  }

  private fun startShizukuProcess(cmd: Array<String>): Process? {
    return runCatching {
        val method =
          Shizuku::class
            .java
            .getDeclaredMethod(
              "newProcess",
              Array<String>::class.java,
              Array<String>::class.java,
              String::class.java,
            )
            .apply { isAccessible = true }
        method.invoke(null, cmd, null, null) as? Process
      }
      .getOrNull()
  }

  private fun statusErrorMessage(status: ShizukuStatus): String {
    return when (status) {
      ShizukuStatus.NOT_INSTALLED -> "Shizuku não está instalado neste dispositivo."
      ShizukuStatus.BINDER_DEAD -> "Shizuku desconectado. Inicie o serviço Shizuku primeiro."
      ShizukuStatus.PERMISSION_REQUIRED -> "Permissão do Shizuku pendente. Toque para autorizar."
      ShizukuStatus.READY -> ""
    }
  }

  companion object {
    const val SHIZUKU_MANAGER_PACKAGE = "moe.shizuku.privileged.api"
    const val SHIZUKU_REQUEST_CODE = 1042
  }
}
