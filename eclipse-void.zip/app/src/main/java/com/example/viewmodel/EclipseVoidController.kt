package com.example.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.example.data.AppStorageRepository
import com.example.data.DeviceStorageInfo
import com.example.data.ExcludedAppItem
import com.example.data.ExcludedAppsRepository
import com.example.data.InstalledAppItem
import com.example.data.MainTab
import com.example.data.ShizukuStatus
import com.example.security.SystemAppGuard
import com.example.shizuku.ShizukuEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EclipseVoidUiState(
  val selectedTab: MainTab = MainTab.INSTALLED,
  val searchQuery: String = "",
  val includeSystemApps: Boolean = false,
  val installedApps: List<InstalledAppItem> = emptyList(),
  val excludedApps: List<ExcludedAppItem> = emptyList(),
  val deviceStorage: DeviceStorageInfo = DeviceStorageInfo(),
  val shizukuStatus: ShizukuStatus = ShizukuStatus.BINDER_DEAD,
  val isLoading: Boolean = true,
  val busyPackageName: String? = null,
  val isBubbleRunning: Boolean = false,
  val systemBlockAlertMessage: String? = null,
  val systemBlockAlertAppName: String? = null,
  val statusMessage: String? = null,
  val hasUsageStatsPermission: Boolean = false,
) {
  val filteredInstalledApps: List<InstalledAppItem>
    get() {
      val query = searchQuery.trim()
      if (query.isEmpty()) return installedApps
      return installedApps.filter {
        it.appName.contains(query, ignoreCase = true) ||
          it.packageName.contains(query, ignoreCase = true)
      }
    }

  val filteredExcludedApps: List<ExcludedAppItem>
    get() {
      val query = searchQuery.trim()
      if (query.isEmpty()) return excludedApps
      return excludedApps.filter {
        it.appName.contains(query, ignoreCase = true) ||
          it.packageName.contains(query, ignoreCase = true)
      }
    }
}

class EclipseVoidController private constructor(private val appContext: Context) {

  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private val storageRepository = AppStorageRepository(appContext)
  private val excludedRepository = ExcludedAppsRepository(appContext)
  val shizukuEngine = ShizukuEngine(appContext)

  private val _uiState = MutableStateFlow(EclipseVoidUiState())
  val uiState: StateFlow<EclipseVoidUiState> = _uiState.asStateFlow()

  init {
    shizukuEngine.startListening()
    scope.launch {
      shizukuEngine.status.collect { status ->
        _uiState.update { it.copy(shizukuStatus = status) }
      }
    }
    refreshAll()
  }

  fun refreshAll() {
    scope.launch {
      _uiState.update { it.copy(isLoading = true) }
      val storage = runCatching { storageRepository.loadDeviceStorage() }.getOrDefault(DeviceStorageInfo())
      val usageGranted = storageRepository.hasUsageStatsPermission()
      val excluded = runCatching { excludedRepository.getAll() }.getOrDefault(emptyList())
      val includeSys = _uiState.value.includeSystemApps
      val installed =
        runCatching { storageRepository.loadInstalledApps(includeSystemApps = includeSys) }
          .getOrDefault(emptyList())
      val shizuku = shizukuEngine.refreshStatus()

      _uiState.update {
        it.copy(
          installedApps = installed,
          excludedApps = excluded,
          deviceStorage = storage,
          shizukuStatus = shizuku,
          hasUsageStatsPermission = usageGranted,
          isLoading = false,
        )
      }
    }
  }

  fun selectTab(tab: MainTab) {
    _uiState.update { it.copy(selectedTab = tab) }
  }

  fun updateSearchQuery(query: String) {
    _uiState.update { it.copy(searchQuery = query) }
  }

  fun toggleIncludeSystemApps() {
    _uiState.update { it.copy(includeSystemApps = !it.includeSystemApps) }
    refreshAll()
  }

  fun setBubbleRunning(running: Boolean) {
    _uiState.update { it.copy(isBubbleRunning = running) }
  }

  fun dismissSystemBlockAlert() {
    _uiState.update { it.copy(systemBlockAlertMessage = null, systemBlockAlertAppName = null) }
  }

  fun clearStatusMessage() {
    _uiState.update { it.copy(statusMessage = null) }
  }

  fun onShizukuActionClicked() {
    val msg = shizukuEngine.requestPermissionOrOpenShizuku()
    if (msg != null) {
      _uiState.update { it.copy(statusMessage = msg) }
    }
  }

  fun excludeApp(app: InstalledAppItem) {
    if (_uiState.value.busyPackageName != null) return

    // Mandatory pre-execution reading & protection check
    val guard = SystemAppGuard.verifyBeforeExecution(appContext, app.packageName, app.appName)
    if (!guard.allowed) {
      _uiState.update {
        it.copy(
          systemBlockAlertMessage = SystemAppGuard.SYSTEM_APP_BLOCKED_MESSAGE,
          systemBlockAlertAppName = "${guard.appName} (${guard.packageName})",
        )
      }
      return
    }

    scope.launch {
      _uiState.update { it.copy(busyPackageName = app.packageName, statusMessage = null) }
      val result = shizukuEngine.clearCacheAndUninstallKeepData(app.packageName)
      if (result.success) {
        excludedRepository.addOrUpdate(
          ExcludedAppItem(
            packageName = app.packageName,
            appName = app.appName,
            sizeBytes = app.sizeBytes,
            excludedAtMillis = System.currentTimeMillis(),
          )
        )
        _uiState.update {
          it.copy(
            busyPackageName = null,
            statusMessage =
              "${app.appName} excluído (${AppStorageRepository.formatSize(app.sizeBytes)} liberados, dados mantidos).",
          )
        }
        refreshAll()
      } else {
        _uiState.update {
          it.copy(
            busyPackageName = null,
            statusMessage =
              result.output.ifBlank { "Falha ao excluir ${app.appName} via Shizuku." },
          )
        }
      }
    }
  }

  fun restoreApp(app: ExcludedAppItem) {
    if (_uiState.value.busyPackageName != null) return

    scope.launch {
      _uiState.update { it.copy(busyPackageName = app.packageName, statusMessage = null) }
      val result = shizukuEngine.restoreExistingPackage(app.packageName)
      if (result.success) {
        excludedRepository.remove(app.packageName)
        _uiState.update {
          it.copy(
            busyPackageName = null,
            statusMessage = "${app.appName} restaurado com dados preservados!",
          )
        }
        refreshAll()
      } else {
        _uiState.update {
          it.copy(
            busyPackageName = null,
            statusMessage =
              result.output.ifBlank { "Não foi possível restaurar ${app.appName} via Shizuku." },
          )
        }
      }
    }
  }

  fun openUsageAccessSettings() {
    runCatching {
      val intent =
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
          data = Uri.parse("package:${appContext.packageName}")
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      appContext.startActivity(intent)
    }.onFailure {
      runCatching {
        val fallback =
          Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          }
        appContext.startActivity(fallback)
      }
    }
  }

  companion object {
    @Volatile private var instance: EclipseVoidController? = null

    fun getInstance(context: Context): EclipseVoidController {
      return instance
        ?: synchronized(this) {
          instance ?: EclipseVoidController(context.applicationContext).also { instance = it }
        }
    }
  }
}
