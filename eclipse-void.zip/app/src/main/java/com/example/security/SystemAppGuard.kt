package com.example.security

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

object SystemAppGuard {
  const val SYSTEM_APP_BLOCKED_MESSAGE =
    "Não é possível: este app é do sistema. Caso ativar, receberá consequências."

  private val protectedPackagePrefixes =
    listOf(
      "com.android.",
      "com.google.android.gms",
      "com.sec.android.",
      "com.miui.",
      "com.xiaomi.",
      "moe.shizuku.privileged.api",
      "com.raylan.eclipsevoid",
    )

  data class VerificationResult(
    val allowed: Boolean,
    val packageName: String,
    val appName: String,
    val flags: Int,
    val blockReasonMessage: String? = null,
  )

  fun isUserDownloadedApp(appInfo: ApplicationInfo): Boolean {
    return (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
      (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0 &&
      !isCriticalPackageName(appInfo.packageName)
  }

  fun isCriticalPackageName(packageName: String): Boolean {
    if (packageName == "android" || packageName.startsWith("android.")) return true
    return protectedPackagePrefixes.any { prefix ->
      packageName.startsWith(prefix) || packageName == prefix.trimEnd('.')
    }
  }

  /**
   * Mandatory pre-execution inspection: reads packageName, app label, and ApplicationInfo flags
   * directly from PackageManager before executing any Shizuku uninstall command.
   */
  fun verifyBeforeExecution(
    context: Context,
    packageName: String,
    fallbackAppName: String = packageName,
  ): VerificationResult {
    return runCatching {
        val pm = context.packageManager
        val appInfo = pm.getApplicationInfo(packageName, PackageManager.GET_META_DATA)
        val resolvedName =
          runCatching { appInfo.loadLabel(pm).toString() }.getOrDefault(fallbackAppName)
        val flags = appInfo.flags
        val isSystemFlag = (flags and ApplicationInfo.FLAG_SYSTEM) != 0
        val isUpdatedSystemFlag = (flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        val isProtectedPkg = isCriticalPackageName(appInfo.packageName)

        if (isSystemFlag || isUpdatedSystemFlag || isProtectedPkg) {
          VerificationResult(
            allowed = false,
            packageName = appInfo.packageName,
            appName = resolvedName,
            flags = flags,
            blockReasonMessage = SYSTEM_APP_BLOCKED_MESSAGE,
          )
        } else {
          VerificationResult(
            allowed = true,
            packageName = appInfo.packageName,
            appName = resolvedName,
            flags = flags,
          )
        }
      }
      .getOrElse {
        if (isCriticalPackageName(packageName)) {
          VerificationResult(
            allowed = false,
            packageName = packageName,
            appName = fallbackAppName,
            flags = 0,
            blockReasonMessage = SYSTEM_APP_BLOCKED_MESSAGE,
          )
        } else {
          VerificationResult(
            allowed = false,
            packageName = packageName,
            appName = fallbackAppName,
            flags = 0,
            blockReasonMessage = SYSTEM_APP_BLOCKED_MESSAGE,
          )
        }
      }
  }
}
