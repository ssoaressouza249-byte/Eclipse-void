package com.example.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

object SecurityGuard {
  const val EXPECTED_APP_NAME = "ECLIPSE VOID"
  const val EXPECTED_PACKAGE_NAME = "com.raylan.eclipsevoid"

  data class IntegrityResult(
    val isOriginal: Boolean,
    val detectedPackage: String,
    val detectedLabel: String,
  )

  fun verifyIntegrity(context: Context): IntegrityResult {
    val pkg = runCatching { context.packageName }.getOrDefault("")
    val appLabel =
      runCatching { context.applicationInfo.loadLabel(context.packageManager).toString() }
        .getOrDefault("")
    val stringResName = runCatching { context.getString(R.string.app_name) }.getOrDefault("")

    val packageValid = pkg == EXPECTED_PACKAGE_NAME
    val nameValid = appLabel == EXPECTED_APP_NAME && stringResName == EXPECTED_APP_NAME

    return IntegrityResult(
      isOriginal = packageValid && nameValid,
      detectedPackage = pkg,
      detectedLabel = appLabel.ifBlank { stringResName },
    )
  }

  fun launchUninstall(context: Context) {
    runCatching {
      val intent =
        Intent(Intent.ACTION_DELETE).apply {
          data = Uri.parse("package:${context.packageName}")
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      context.startActivity(intent)
    }
  }
}

@Composable
fun SecurityGuardGate(content: @Composable () -> Unit) {
  val context = LocalContext.current
  val integrity = remember(context) { SecurityGuard.verifyIntegrity(context) }

  if (integrity.isOriginal) {
    content()
  } else {
    BackHandler(enabled = true) {}
    TamperedLockScreen(
      detectedPackage = integrity.detectedPackage,
      detectedLabel = integrity.detectedLabel,
      onUninstallClick = { SecurityGuard.launchUninstall(context) },
    )
  }
}

@Composable
private fun TamperedLockScreen(
  detectedPackage: String,
  detectedLabel: String,
  onUninstallClick: () -> Unit,
) {
  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.verticalGradient(colors = listOf(Color(0xFF450A0A), Color(0xFF7F1D1D), Color(0xFF2B0404)))
        )
        .safeDrawingPadding()
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .background(Color(0xCC1F0404), RoundedCornerShape(24.dp))
          .border(2.dp, Color(0xFFFF453A), RoundedCornerShape(24.dp))
          .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Icon(
        imageVector = Icons.Rounded.Warning,
        contentDescription = "Alerta de integridade",
        tint = Color(0xFFFF453A),
        modifier = Modifier.size(64.dp),
      )

      Text(
        text = "INTEGRIDADE COMPROMETIDA",
        color = Color.White,
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 20.sp,
        textAlign = TextAlign.Center,
      )

      Text(
        text =
          "Este aplicativo foi modificado fora dos padrões originais de ECLIPSE VOID (com.raylan.eclipsevoid) e foi bloqueado permanentemente.",
        color = Color(0xFFFECACA),
        fontFamily = FontFamily.Default,
        fontSize = 14.sp,
        textAlign = TextAlign.Center,
      )

      Text(
        text = "Nome: $detectedLabel\nPacote: $detectedPackage",
        color = Color(0xFFFCA5A5),
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(8.dp))

      Button(
        onClick = onUninstallClick,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = Color(0xFFDC2626),
            contentColor = Color.White,
          ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().height(54.dp).testTag("security_uninstall_button"),
      ) {
        Icon(
          imageVector = Icons.Rounded.DeleteForever,
          contentDescription = null,
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.size(8.dp))
        Text(
          text = "DESINSTALAR AGORA",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.ExtraBold,
        )
      }
    }
  }
}
