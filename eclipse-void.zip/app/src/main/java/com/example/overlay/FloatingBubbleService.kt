package com.example.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.ui.components.EclipseVoidDashboardContent
import com.example.ui.theme.EarthEmerald
import com.example.ui.theme.EclipseVoidTheme
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.SolarOrange
import com.example.ui.theme.VoidSpaceBlack
import com.example.viewmodel.EclipseVoidController
import kotlin.math.roundToInt

class FloatingBubbleService : Service() {

  private var windowManager: WindowManager? = null
  private var bubbleView: ComposeView? = null
  private var expandedView: ComposeView? = null
  private var bubbleLifecycleOwner: OverlayLifecycleOwner? = null
  private var expandedLifecycleOwner: OverlayLifecycleOwner? = null
  private var bubbleParams: WindowManager.LayoutParams? = null
  private var isExpanded = false

  private val controller: EclipseVoidController by lazy {
    EclipseVoidController.getInstance(applicationContext)
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    startAsForegroundService()

    val canOverlay = runCatching { Settings.canDrawOverlays(this) }.getOrDefault(false)
    if (!canOverlay) {
      stopSelfSafely()
      return
    }

    windowManager = runCatching { getSystemService(WINDOW_SERVICE) as WindowManager }.getOrNull()
    if (windowManager == null) {
      stopSelfSafely()
      return
    }

    controller.setBubbleRunning(true)
    showCollapsedBubble()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_STOP -> stopSelfSafely()
      ACTION_EXPAND -> {
        if (!isExpanded) showExpandedPanel()
      }
    }
    return START_STICKY
  }

  private fun startAsForegroundService() {
    runCatching {
      val nm = getSystemService(NotificationManager::class.java)
      val channel =
        NotificationChannel(
          CHANNEL_ID,
          getString(R.string.bubble_service_channel_name),
          NotificationManager.IMPORTANCE_LOW,
        )
      nm?.createNotificationChannel(channel)

      val openIntent =
        Intent(this, MainActivity::class.java).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
      val pendingIntent =
        PendingIntent.getActivity(
          this,
          0,
          openIntent,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

      val notification: Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
          .setContentTitle(getString(R.string.bubble_service_notification_title))
          .setContentText(getString(R.string.bubble_service_notification_text))
          .setSmallIcon(R.mipmap.ic_launcher_round)
          .setOngoing(true)
          .setContentIntent(pendingIntent)
          .build()

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        startForeground(
          NOTIFICATION_ID,
          notification,
          ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
        )
      } else {
        startForeground(NOTIFICATION_ID, notification)
      }
    }
  }

  private fun showCollapsedBubble() {
    runCatching {
      removeExpandedView()
      if (bubbleView != null) return@runCatching

      val metrics = resources.displayMetrics
      val bubbleSizePx = (62 * metrics.density).roundToInt()

      val params =
        WindowManager.LayoutParams(
            bubbleSizePx,
            bubbleSizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
              WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
          )
          .apply {
            gravity = Gravity.TOP or Gravity.START
            x = (metrics.widthPixels - bubbleSizePx - (16 * metrics.density).roundToInt()).coerceAtLeast(0)
            y = (metrics.heightPixels * 0.35f).roundToInt()
          }
      bubbleParams = params

      val owner = OverlayLifecycleOwner().apply {
        onCreate()
        onResume()
      }
      bubbleLifecycleOwner = owner

      val composeView =
        ComposeView(this).apply {
          setViewTreeLifecycleOwner(owner)
          setViewTreeViewModelStoreOwner(owner)
          setViewTreeSavedStateRegistryOwner(owner)
          setContent {
            EclipseVoidTheme {
              Box(
                modifier =
                  Modifier.fillMaxSize()
                    .padding(2.dp)
                    .shadow(8.dp, CircleShape)
                    .clip(CircleShape)
                    .background(VoidSpaceBlack)
                    .border(
                      width = 2.dp,
                      brush = Brush.sweepGradient(listOf(SolarOrange, LunarCyan, EarthEmerald, SolarOrange)),
                      shape = CircleShape,
                    )
                    .pointerInput(Unit) {
                      detectDragGestures { change, dragAmount ->
                        change.consume()
                        val p = bubbleParams ?: return@detectDragGestures
                        val maxX = (resources.displayMetrics.widthPixels - bubbleSizePx).coerceAtLeast(0)
                        val maxY = (resources.displayMetrics.heightPixels - bubbleSizePx).coerceAtLeast(0)
                        p.x = (p.x + dragAmount.x.roundToInt()).coerceIn(0, maxX)
                        p.y = (p.y + dragAmount.y.roundToInt()).coerceIn(0, maxY)
                        runCatching { windowManager?.updateViewLayout(this@apply, p) }
                      }
                    }
                    .clickable { showExpandedPanel() }
                    .testTag("floating_bubble_widget"),
                contentAlignment = Alignment.Center,
              ) {
                Image(
                  painter = painterResource(id = R.drawable.ic_launcher_foreground),
                  contentDescription = "Abrir painel ECLIPSE VOID",
                  modifier = Modifier.size(54.dp).clip(CircleShape),
                )
              }
            }
          }
        }

      bubbleView = composeView
      isExpanded = false
      windowManager?.addView(composeView, params)
    }
  }

  private fun showExpandedPanel() {
    runCatching {
      removeBubbleView()
      if (expandedView != null) return@runCatching

      controller.refreshAll()

      val metrics = resources.displayMetrics
      val panelWidth = (metrics.widthPixels * 0.94f).roundToInt()
      val panelHeight = (metrics.heightPixels * 0.84f).roundToInt()

      val params =
        WindowManager.LayoutParams(
            panelWidth,
            panelHeight,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
              WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT,
          )
          .apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
          }

      val owner = OverlayLifecycleOwner().apply {
        onCreate()
        onResume()
      }
      expandedLifecycleOwner = owner

      val composeView =
        ComposeView(this).apply {
          setViewTreeLifecycleOwner(owner)
          setViewTreeViewModelStoreOwner(owner)
          setViewTreeSavedStateRegistryOwner(owner)
          setContent {
            EclipseVoidTheme {
              val uiState by controller.uiState.collectAsState()
              Box(
                modifier =
                  Modifier.fillMaxSize()
                    .clip(RoundedCornerShape(24.dp))
                    .background(VoidSpaceBlack)
                    .border(
                      width = 1.8.dp,
                      brush = Brush.linearGradient(listOf(SolarOrange, EarthEmerald, LunarCyan)),
                      shape = RoundedCornerShape(24.dp),
                    )
              ) {
                EclipseVoidDashboardContent(
                  uiState = uiState,
                  isOverlayMode = true,
                  onSelectTab = controller::selectTab,
                  onSearchQueryChange = controller::updateSearchQuery,
                  onToggleIncludeSystem = controller::toggleIncludeSystemApps,
                  onRefreshClick = controller::refreshAll,
                  onShizukuClick = controller::onShizukuActionClicked,
                  onUsageAccessClick = controller::openUsageAccessSettings,
                  onExcludeApp = controller::excludeApp,
                  onRestoreApp = controller::restoreApp,
                  onDismissStatusMessage = controller::clearStatusMessage,
                  onDismissSystemBlockAlert = controller::dismissSystemBlockAlert,
                  onMinimizeOverlay = { showCollapsedBubble() },
                  onCloseOverlay = { stopSelfSafely() },
                )
              }
            }
          }
        }

      expandedView = composeView
      isExpanded = true
      windowManager?.addView(composeView, params)
    }
  }

  private fun removeBubbleView() {
    runCatching {
      bubbleView?.let { view ->
        bubbleLifecycleOwner?.onPause()
        bubbleLifecycleOwner?.onDestroy()
        windowManager?.removeViewImmediate(view)
      }
    }
    bubbleView = null
    bubbleLifecycleOwner = null
  }

  private fun removeExpandedView() {
    runCatching {
      expandedView?.let { view ->
        expandedLifecycleOwner?.onPause()
        expandedLifecycleOwner?.onDestroy()
        windowManager?.removeViewImmediate(view)
      }
    }
    expandedView = null
    expandedLifecycleOwner = null
  }

  private fun stopSelfSafely() {
    runCatching {
      removeBubbleView()
      removeExpandedView()
      controller.setBubbleRunning(false)
      stopForeground(STOP_FOREGROUND_REMOVE)
      stopSelf()
    }
  }

  override fun onDestroy() {
    removeBubbleView()
    removeExpandedView()
    controller.setBubbleRunning(false)
    super.onDestroy()
  }

  companion object {
    private const val CHANNEL_ID = "eclipse_void_bubble_channel"
    private const val NOTIFICATION_ID = 7701
    const val ACTION_STOP = "com.raylan.eclipsevoid.ACTION_STOP_BUBBLE"
    const val ACTION_EXPAND = "com.raylan.eclipsevoid.ACTION_EXPAND_BUBBLE"

    fun start(context: Context) {
      runCatching {
        val intent = Intent(context, FloatingBubbleService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          context.startForegroundService(intent)
        } else {
          context.startService(intent)
        }
      }
    }

    fun stop(context: Context) {
      runCatching {
        val intent =
          Intent(context, FloatingBubbleService::class.java).apply { action = ACTION_STOP }
        context.startService(intent)
      }
    }
  }
}
