package com.example.overlay

import android.os.Bundle
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner

class OverlayLifecycleOwner : LifecycleOwnerWithStore, SavedStateRegistryOwner {

  private val lifecycleRegistry = LifecycleRegistry(this)
  private val savedStateRegistryController = SavedStateRegistryController.create(this)
  private val store = ViewModelStore()

  override val lifecycle: Lifecycle
    get() = lifecycleRegistry

  override val savedStateRegistry: SavedStateRegistry
    get() = savedStateRegistryController.savedStateRegistry

  override val viewModelStore: ViewModelStore
    get() = store

  fun onCreate(savedState: Bundle? = null) {
    runCatching {
      savedStateRegistryController.performRestore(savedState)
      lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }
  }

  fun onResume() {
    runCatching {
      lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
      lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }
  }

  fun onPause() {
    runCatching {
      lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
      lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
    }
  }

  fun onDestroy() {
    runCatching {
      lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
      store.clear()
    }
  }
}

interface LifecycleOwnerWithStore : androidx.lifecycle.LifecycleOwner, ViewModelStoreOwner
