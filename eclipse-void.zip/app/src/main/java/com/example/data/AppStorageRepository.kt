package com.example.data

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Environment
import android.os.Process
import android.os.StatFs
import com.example.security.SystemAppGuard
import java.io.File
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppStorageRepository(private val context: Context) {

  fun loadDeviceStorage(): DeviceStorageInfo {
    return runCatching {
        val statFs = StatFs(Environment.getDataDirectory().path)
        val total = statFs.totalBytes
        val free = statFs.availableBytes
        val used = (total - free).coerceAtLeast(0L)
        DeviceStorageInfo(totalBytes = total, freeBytes = free, usedBytes = used)
      }
      .getOrDefault(DeviceStorageInfo())
  }

  fun hasUsageStatsPermission(): Boolean {
    return runCatching {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode =
          appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName,
          )
        mode == AppOpsManager.MODE_ALLOWED
      }
      .getOrDefault(false)
  }

  suspend fun loadInstalledApps(includeSystemApps: Boolean): List<InstalledAppItem> =
    withContext(Dispatchers.IO) {
      runCatching {
          val pm = context.packageManager
          val storageStatsManager =
            runCatching {
                context.getSystemService(Context.STORAGE_STATS_SERVICE) as? StorageStatsManager
              }
              .getOrNull()
          val usageGranted = hasUsageStatsPermission()
          val userHandle = Process.myUserHandle()

          val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
          packages
            .asSequence()
            .filter { appInfo ->
              if (includeSystemApps) {
                true
              } else {
                // Default filter requested: only user-downloaded apps
                (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0
              }
            }
            .map { appInfo ->
              val label =
                runCatching { appInfo.loadLabel(pm).toString() }
                  .getOrDefault(appInfo.packageName)
                  .ifBlank { appInfo.packageName }

              val icon = runCatching { appInfo.loadIcon(pm) }.getOrNull()
              val sizeBytes =
                computeAppSizeBytes(
                  appInfo = appInfo,
                  storageStatsManager = if (usageGranted) storageStatsManager else null,
                  userHandle = userHandle,
                )

              val isSystemOrProtected =
                (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                  (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0 ||
                  SystemAppGuard.isCriticalPackageName(appInfo.packageName)

              InstalledAppItem(
                packageName = appInfo.packageName,
                appName = label,
                sizeBytes = sizeBytes,
                icon = icon,
                isSystemOrProtected = isSystemOrProtected,
              )
            }
            .sortedByDescending { it.sizeBytes }
            .toList()
        }
        .getOrDefault(emptyList())
    }

  private fun computeAppSizeBytes(
    appInfo: ApplicationInfo,
    storageStatsManager: StorageStatsManager?,
    userHandle: android.os.UserHandle,
  ): Long {
    if (storageStatsManager != null) {
      val statsBytes =
        runCatching {
            val stats =
              storageStatsManager.queryStatsForPackage(
                appInfo.storageUuid,
                appInfo.packageName,
                userHandle,
              )
            stats.appBytes + stats.dataBytes + stats.cacheBytes
          }
          .getOrNull()
      if (statsBytes != null && statsBytes > 0L) {
        return statsBytes
      }
    }

    return runCatching {
        var total = 0L
        appInfo.sourceDir?.let { path ->
          val file = File(path)
          if (file.exists()) total += file.length()
        }
        appInfo.splitSourceDirs?.forEach { splitPath ->
          val file = File(splitPath)
          if (file.exists()) total += file.length()
        }
        appInfo.nativeLibraryDir?.let { libDir ->
          val dir = File(libDir)
          if (dir.exists() && dir.isDirectory) {
            dir.listFiles()?.forEach { libFile ->
              if (libFile.isFile) total += libFile.length()
            }
          }
        }
        total
      }
      .getOrDefault(0L)
  }

  companion object {
    fun formatSize(bytes: Long): String {
      if (bytes <= 0L) return "0 MB"
      val kb = bytes / 1024.0
      val mb = kb / 1024.0
      val gb = mb / 1024.0
      return when {
        gb >= 1.0 -> String.format(Locale.getDefault(), "%.2f GB", gb)
        mb >= 1.0 -> String.format(Locale.getDefault(), "%.1f MB", mb)
        else -> String.format(Locale.getDefault(), "%.0f KB", kb.coerceAtLeast(1.0))
      }
    }
  }
}
