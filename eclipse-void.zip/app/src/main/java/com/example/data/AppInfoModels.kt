package com.example.data

import android.graphics.drawable.Drawable

data class InstalledAppItem(
  val packageName: String,
  val appName: String,
  val sizeBytes: Long,
  val icon: Drawable?,
  val isSystemOrProtected: Boolean,
)

data class ExcludedAppItem(
  val packageName: String,
  val appName: String,
  val sizeBytes: Long,
  val excludedAtMillis: Long,
)

data class DeviceStorageInfo(
  val totalBytes: Long = 0L,
  val freeBytes: Long = 0L,
  val usedBytes: Long = 0L,
) {
  val usedFraction: Float
    get() =
      if (totalBytes <= 0L) 0f
      else (usedBytes.toDouble() / totalBytes.toDouble()).toFloat().coerceIn(0f, 1f)
}

enum class MainTab {
  INSTALLED,
  EXCLUDED,
}

enum class ShizukuStatus {
  NOT_INSTALLED,
  BINDER_DEAD,
  PERMISSION_REQUIRED,
  READY,
}
