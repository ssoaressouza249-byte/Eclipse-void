package com.example.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ExcludedAppsRepository(context: Context) {
  private val prefs =
    context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  fun getAll(): List<ExcludedAppItem> {
    return runCatching {
        val raw = prefs.getString(KEY_EXCLUDED_APPS, "[]") ?: "[]"
        val array = JSONArray(raw)
        val result = ArrayList<ExcludedAppItem>(array.length())
        for (i in 0 until array.length()) {
          val obj = array.optJSONObject(i) ?: continue
          val pkg = obj.optString("packageName")
          val name = obj.optString("appName")
          if (pkg.isNotBlank()) {
            result.add(
              ExcludedAppItem(
                packageName = pkg,
                appName = name.ifBlank { pkg },
                sizeBytes = obj.optLong("sizeBytes", 0L),
                excludedAtMillis = obj.optLong("excludedAtMillis", 0L),
              )
            )
          }
        }
        result.sortedByDescending { it.excludedAtMillis }
      }
      .getOrDefault(emptyList())
  }

  fun addOrUpdate(item: ExcludedAppItem) {
    runCatching {
      val current = getAll().filterNot { it.packageName == item.packageName }.toMutableList()
      current.add(0, item)
      saveList(current)
    }
  }

  fun remove(packageName: String) {
    runCatching {
      val updated = getAll().filterNot { it.packageName == packageName }
      saveList(updated)
    }
  }

  private fun saveList(items: List<ExcludedAppItem>) {
    val array = JSONArray()
    items.forEach { item ->
      val obj =
        JSONObject().apply {
          put("packageName", item.packageName)
          put("appName", item.appName)
          put("sizeBytes", item.sizeBytes)
          put("excludedAtMillis", item.excludedAtMillis)
        }
      array.put(obj)
    }
    prefs.edit().putString(KEY_EXCLUDED_APPS, array.toString()).apply()
  }

  companion object {
    private const val PREFS_NAME = "eclipse_void_excluded_apps"
    private const val KEY_EXCLUDED_APPS = "excluded_apps_json"
  }
}
