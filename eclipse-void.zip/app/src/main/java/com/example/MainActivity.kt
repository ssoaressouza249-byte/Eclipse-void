package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.overlay.FloatingBubbleService
import com.example.security.SecurityGuardGate
import com.example.ui.components.EclipseVoidDashboardContent
import com.example.ui.theme.EclipseVoidTheme
import com.example.ui.theme.VoidSpaceBlack
import com.example.viewmodel.EclipseVoidController

class MainActivity : ComponentActivity() {

  private lateinit var controller: EclipseVoidController

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
    )

    controller = EclipseVoidController.getInstance(applicationContext)

    setContent {
      EclipseVoidTheme {
        SecurityGuardGate {
          val context = LocalContext.current
          val uiState by controller.uiState.collectAsStateWithLifecycle()

          val notificationPermissionLauncher =
            rememberLauncherForActivityResult(
              contract = ActivityResultContracts.RequestPermission()
            ) {
              if (runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false)) {
                FloatingBubbleService.start(context)
              }
            }

          val overlayPermissionLauncher =
            rememberLauncherForActivityResult(
              contract = ActivityResultContracts.StartActivityForResult()
            ) {
              val granted = runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false)
              if (granted) {
                startBubbleWithOptionalNotificationPermission(
                  context = context,
                  requestNotification = { notificationPermissionLauncher.launch(it) },
                )
              }
            }

          Box(modifier = Modifier.fillMaxSize().background(VoidSpaceBlack)) {
            Scaffold(
              modifier = Modifier.fillMaxSize(),
              containerColor = Color.Transparent,
              contentWindowInsets = WindowInsets.safeDrawing,
            ) { innerPadding ->
              EclipseVoidDashboardContent(
                uiState = uiState,
                isOverlayMode = false,
                onSelectTab = controller::selectTab,
                onSearchQueryChange = controller::updateSearchQuery,
                onToggleIncludeSystem = controller::toggleIncludeSystemApps,
                onRefreshClick = controller::refreshAll,
                onShizukuClick = controller::onShizukuActionClicked,
                onUsageAccessClick = controller::openUsageAccessSettings,
                onExcludeApp = controller::excludeApp,
                onRestoreApp = controller::restoreApp,
                onDismissStatusMessage = controller::clearStatusMessage,
                onDismissSystemBlockAlert = controller::dismissSystemBlockAlert,
                onToggleFloatingBubble = {
                  if (uiState.isBubbleRunning) {
                    FloatingBubbleService.stop(context)
                  } else {
                    val canOverlay =
                      runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false)
                    if (canOverlay) {
                      startBubbleWithOptionalNotificationPermission(
                        context = context,
                        requestNotification = { notificationPermissionLauncher.launch(it) },
                      )
                    } else {
                      runCatching {
                        val intent =
                          Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}"),
                          )
                        overlayPermissionLauncher.launch(intent)
                      }
                    }
                  }
                },
                modifier = Modifier.fillMaxSize().padding(innerPadding),
              )
            }
          }
        }
      }
    }
  }

  override fun onResume() {
    super.onResume()
    if (::controller.isInitialized) {
      controller.refreshAll()
    }
  }

  private fun startBubbleWithOptionalNotificationPermission(
    context: android.content.Context,
    requestNotification: (String) -> Unit,
  ) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val hasPostNotif =
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      if (!hasPostNotif) {
        requestNotification(Manifest.permission.POST_NOTIFICATIONS)
        return
      }
    }
    FloatingBubbleService.start(context)
  }
}
