package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.BubbleChart
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Minimize
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RestoreFromTrash
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.AppStorageRepository
import com.example.data.MainTab
import com.example.data.ShizukuStatus
import com.example.ui.theme.DangerBrightRed
import com.example.ui.theme.EarthBrightEmerald
import com.example.ui.theme.EarthEmerald
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.SolarGold
import com.example.ui.theme.SolarOrange
import com.example.ui.theme.StarWhite
import com.example.ui.theme.TranslucentCardSurface
import com.example.ui.theme.VoidSpaceBlack
import com.example.viewmodel.EclipseVoidUiState

@Composable
fun EclipseVoidDashboardContent(
  uiState: EclipseVoidUiState,
  isOverlayMode: Boolean,
  onSelectTab: (MainTab) -> Unit,
  onSearchQueryChange: (String) -> Unit,
  onToggleIncludeSystem: () -> Unit,
  onRefreshClick: () -> Unit,
  onShizukuClick: () -> Unit,
  onUsageAccessClick: () -> Unit,
  onExcludeApp: (com.example.data.InstalledAppItem) -> Unit,
  onRestoreApp: (com.example.data.ExcludedAppItem) -> Unit,
  onDismissStatusMessage: () -> Unit,
  onDismissSystemBlockAlert: () -> Unit,
  onToggleFloatingBubble: () -> Unit = {},
  onMinimizeOverlay: () -> Unit = {},
  onCloseOverlay: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize()) {
    // Animated cosmic battle canvas behind the entire interface
    CosmicBattleBackground(modifier = Modifier.fillMaxSize())

    Box(
      modifier = Modifier.fillMaxSize(),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier =
          Modifier.fillMaxSize()
            .widthIn(max = 640.dp)
            .padding(horizontal = if (isOverlayMode) 12.dp else 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        // 1. Top Header Bar
        DashboardHeader(
          isOverlayMode = isOverlayMode,
          isBubbleRunning = uiState.isBubbleRunning,
          onToggleFloatingBubble = onToggleFloatingBubble,
          onRefreshClick = onRefreshClick,
          onMinimizeOverlay = onMinimizeOverlay,
          onCloseOverlay = onCloseOverlay,
        )

        // 2. Storage & Shizuku Panel
        StorageAndShizukuCard(
          uiState = uiState,
          onShizukuClick = onShizukuClick,
          onUsageAccessClick = onUsageAccessClick,
        )

        // 3. Feedback Banner if present
        AnimatedVisibility(visible = !uiState.statusMessage.isNullOrBlank()) {
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(TranslucentCardSurface)
                .border(1.dp, LunarCyan.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = uiState.statusMessage.orEmpty(),
              style = MaterialTheme.typography.bodyMedium,
              color = StarWhite,
              modifier = Modifier.weight(1f),
            )
            IconButton(
              onClick = onDismissStatusMessage,
              modifier = Modifier.size(32.dp),
            ) {
              Icon(
                imageVector = Icons.Rounded.Close,
                contentDescription = "Fechar mensagem",
                tint = MutedSlate,
                modifier = Modifier.size(16.dp),
              )
            }
          }
        }

        // 4. Search Bar + User/System Filter Toggle
        SearchAndFilterRow(
          searchQuery = uiState.searchQuery,
          includeSystemApps = uiState.includeSystemApps,
          onSearchQueryChange = onSearchQueryChange,
          onToggleIncludeSystem = onToggleIncludeSystem,
        )

        // 5. Two Primary Tabs: APPS INSTALADOS | APPS EXCLUÍDOS
        EclipseTabBar(
          selectedTab = uiState.selectedTab,
          installedCount = uiState.filteredInstalledApps.size,
          excludedCount = uiState.filteredExcludedApps.size,
          onSelectTab = onSelectTab,
        )

        // 6. Main App List
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
          when {
            uiState.isLoading -> {
              Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(10.dp),
                  modifier =
                    Modifier.clip(RoundedCornerShape(18.dp))
                      .background(TranslucentCardSurface)
                      .border(1.dp, LunarCyan.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                      .padding(24.dp),
                ) {
                  CircularProgressIndicator(color = LunarCyan)
                  Text(
                    text = "Escaneando aplicativos...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StarWhite,
                  )
                }
              }
            }

            uiState.selectedTab == MainTab.INSTALLED -> {
              val apps = uiState.filteredInstalledApps
              if (apps.isEmpty()) {
                EmptyStateCard(
                  icon = Icons.Rounded.Apps,
                  title = "Nenhum app encontrado",
                  subtitle =
                    if (uiState.searchQuery.isNotBlank()) "Tente limpar a busca para ver os apps baixados."
                    else "Nenhum app do usuário encontrado.",
                )
              } else {
                LazyColumn(
                  modifier = Modifier.fillMaxSize().testTag("installed_apps_list"),
                  contentPadding = PaddingValues(bottom = 8.dp),
                  verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  items(items = apps, key = { it.packageName }) { app ->
                    InstalledAppCard(
                      app = app,
                      isBusy = uiState.busyPackageName == app.packageName,
                      anyBusy = uiState.busyPackageName != null,
                      onExcludeClick = { onExcludeApp(app) },
                    )
                  }
                }
              }
            }

            uiState.selectedTab == MainTab.EXCLUDED -> {
              val excluded = uiState.filteredExcludedApps
              if (excluded.isEmpty()) {
                EmptyStateCard(
                  icon = Icons.Rounded.RestoreFromTrash,
                  title = "Nenhum app excluído",
                  subtitle =
                    "Apps removidos via EXCLUIR APP aparecerão aqui para restauração instantânea.",
                )
              } else {
                LazyColumn(
                  modifier = Modifier.fillMaxSize().testTag("excluded_apps_list"),
                  contentPadding = PaddingValues(bottom = 8.dp),
                  verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  items(items = excluded, key = { it.packageName }) { app ->
                    ExcludedAppCard(
                      app = app,
                      isBusy = uiState.busyPackageName == app.packageName,
                      anyBusy = uiState.busyPackageName != null,
                      onRestoreClick = { onRestoreApp(app) },
                    )
                  }
                }
              }
            }
          }
        }

        // 7. Official Credits Footer
        Box(
          modifier =
            Modifier.fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(TranslucentCardSurface)
              .border(
                1.dp,
                Brush.horizontalGradient(
                  listOf(SolarOrange.copy(alpha = 0.45f), EarthEmerald.copy(alpha = 0.55f), LunarCyan.copy(alpha = 0.45f))
                ),
                RoundedCornerShape(12.dp),
              )
              .padding(vertical = 8.dp, horizontal = 12.dp),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = stringResource(R.string.credits_raylan),
            style = MaterialTheme.typography.labelMedium,
            color = StarWhite,
            textAlign = TextAlign.Center,
            modifier = Modifier.testTag("credits_footer_text"),
          )
        }
      }
    }

    // Mandatory Red Block Modal when attempting to modify a system/protected app
    if (!uiState.systemBlockAlertMessage.isNullOrBlank()) {
      SystemAppBlockedModal(
        appLabel = uiState.systemBlockAlertAppName,
        message = uiState.systemBlockAlertMessage,
        onDismiss = onDismissSystemBlockAlert,
      )
    }
  }
}

@Composable
private fun DashboardHeader(
  isOverlayMode: Boolean,
  isBubbleRunning: Boolean,
  onToggleFloatingBubble: () -> Unit,
  onRefreshClick: () -> Unit,
  onMinimizeOverlay: () -> Unit,
  onCloseOverlay: () -> Unit,
) {
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(18.dp))
        .background(TranslucentCardSurface)
        .border(
          1.2.dp,
          Brush.horizontalGradient(listOf(SolarOrange, EarthEmerald, LunarCyan)),
          RoundedCornerShape(18.dp),
        )
        .padding(horizontal = 12.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = "ECLIPSE VOID",
        style = MaterialTheme.typography.headlineMedium,
        fontSize = if (isOverlayMode) 17.sp else 20.sp,
        color = StarWhite,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
      Text(
        text = if (isOverlayMode) "MODO FLUTUANTE UNIVERSAL" else "SHIZUKU STORAGE ENGINE",
        fontFamily = FontFamily.Monospace,
        fontSize = 10.sp,
        color = LunarCyan,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }

    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      IconButton(
        onClick = onRefreshClick,
        modifier = Modifier.size(48.dp).testTag("refresh_apps_button"),
      ) {
        Icon(
          imageVector = Icons.Rounded.Refresh,
          contentDescription = "Atualizar lista",
          tint = LunarCyan,
        )
      }

      if (isOverlayMode) {
        // Minimize back to bubble (—)
        IconButton(
          onClick = onMinimizeOverlay,
          modifier =
            Modifier.size(48.dp)
              .clip(CircleShape)
              .background(Color(0x3300E5FF))
              .testTag("overlay_minimize_button"),
        ) {
          Icon(
            imageVector = Icons.Rounded.Minimize,
            contentDescription = "Minimizar para bolinha",
            tint = LunarCyan,
          )
        }
        // Close floating overlay (X)
        IconButton(
          onClick = onCloseOverlay,
          modifier =
            Modifier.size(48.dp)
              .clip(CircleShape)
              .background(Color(0x33FF3B30))
              .testTag("overlay_close_button"),
        ) {
          Icon(
            imageVector = Icons.Rounded.Close,
            contentDescription = "Fechar janela flutuante",
            tint = DangerBrightRed,
          )
        }
      } else {
        Button(
          onClick = onToggleFloatingBubble,
          colors =
            ButtonDefaults.buttonColors(
              containerColor = if (isBubbleRunning) EarthEmerald else LunarCyan,
              contentColor = VoidSpaceBlack,
            ),
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
          modifier = Modifier.heightIn(min = 48.dp).testTag("activate_bubble_button"),
        ) {
          Icon(
            imageVector = Icons.Rounded.BubbleChart,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (isBubbleRunning) "Bolinha Ativa" else "Ativar Bolinha Flutuante",
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            maxLines = 1,
          )
        }
      }
    }
  }
}

@Composable
private fun StorageAndShizukuCard(
  uiState: EclipseVoidUiState,
  onShizukuClick: () -> Unit,
  onUsageAccessClick: () -> Unit,
) {
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .background(TranslucentCardSurface)
        .border(1.dp, LunarCyan.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
        .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Icon(
          imageVector = Icons.Rounded.Storage,
          contentDescription = "Armazenamento",
          tint = SolarGold,
          modifier = Modifier.size(18.dp),
        )
        Text(
          text =
            "Livre: ${AppStorageRepository.formatSize(uiState.deviceStorage.freeBytes)} / Total: ${AppStorageRepository.formatSize(uiState.deviceStorage.totalBytes)}",
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 12.sp,
          color = StarWhite,
        )
      }

      if (!uiState.hasUsageStatsPermission) {
        Text(
          text = "Tam. Exato",
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          color = LunarCyan,
          modifier =
            Modifier.clip(RoundedCornerShape(8.dp))
              .background(Color(0x2200E5FF))
              .border(1.dp, LunarCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
              .clickable(onClick = onUsageAccessClick)
              .padding(horizontal = 8.dp, vertical = 4.dp)
              .testTag("grant_usage_stats_chip"),
        )
      }
    }

    // Neon Storage Progress Bar
    Box(
      modifier =
        Modifier.fillMaxWidth()
          .height(9.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(Color(0x661E293B))
    ) {
      Box(
        modifier =
          Modifier.fillMaxWidth(uiState.deviceStorage.usedFraction)
            .height(9.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(
              Brush.horizontalGradient(listOf(EarthEmerald, LunarCyan, SolarOrange))
            )
      )
    }

    // Shizuku Connection Status Row
    val (statusText, statusColor) =
      when (uiState.shizukuStatus) {
        ShizukuStatus.READY -> "Shizuku: Conectado e Pronto" to EarthBrightEmerald
        ShizukuStatus.PERMISSION_REQUIRED -> "Shizuku: Toque para Autorizar" to SolarGold
        ShizukuStatus.BINDER_DEAD -> "Shizuku: Desconectado (Toque p/ Abrir)" to SolarOrange
        ShizukuStatus.NOT_INSTALLED -> "Shizuku: Não Instalado" to DangerBrightRed
      }

    Row(
      modifier =
        Modifier.fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(Color(0x4404050C))
          .border(1.dp, statusColor.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
          .clickable(onClick = onShizukuClick)
          .padding(horizontal = 10.dp, vertical = 8.dp)
          .testTag("shizuku_status_card"),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Box(
          modifier = Modifier.size(10.dp).clip(CircleShape).background(statusColor)
        )
        Icon(
          imageVector = Icons.Rounded.Bolt,
          contentDescription = null,
          tint = statusColor,
          modifier = Modifier.size(16.dp),
        )
        Text(
          text = statusText,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.SemiBold,
          fontSize = 12.sp,
          color = statusColor,
        )
      }
      Icon(
        imageVector = Icons.Rounded.Security,
        contentDescription = "Proteção anti-sistema ativa",
        tint = EarthBrightEmerald,
        modifier = Modifier.size(16.dp),
      )
    }
  }
}

@Composable
private fun SearchAndFilterRow(
  searchQuery: String,
  includeSystemApps: Boolean,
  onSearchQueryChange: (String) -> Unit,
  onToggleIncludeSystem: () -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    OutlinedTextField(
      value = searchQuery,
      onValueChange = onSearchQueryChange,
      singleLine = true,
      placeholder = {
        Text(
          text = "Buscar app ou pacote...",
          style = MaterialTheme.typography.bodyMedium,
          color = MutedSlate,
        )
      },
      leadingIcon = {
        Icon(
          imageVector = Icons.Rounded.Search,
          contentDescription = "Buscar",
          tint = LunarCyan,
        )
      },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { onSearchQueryChange("") }) {
            Icon(
              imageVector = Icons.Rounded.Close,
              contentDescription = "Limpar busca",
              tint = MutedSlate,
            )
          }
        }
      },
      colors =
        OutlinedTextFieldDefaults.colors(
          focusedTextColor = StarWhite,
          unfocusedTextColor = StarWhite,
          focusedContainerColor = TranslucentCardSurface,
          unfocusedContainerColor = TranslucentCardSurface,
          focusedBorderColor = LunarCyan,
          unfocusedBorderColor = LunarCyan.copy(alpha = 0.4f),
          cursorColor = LunarCyan,
        ),
      shape = RoundedCornerShape(14.dp),
      modifier = Modifier.weight(1f).testTag("search_apps_input"),
    )

    Column(
      modifier =
        Modifier.heightIn(min = 52.dp)
          .clip(RoundedCornerShape(14.dp))
          .background(TranslucentCardSurface)
          .border(
            1.dp,
            if (includeSystemApps) SolarOrange else EarthEmerald.copy(alpha = 0.7f),
            RoundedCornerShape(14.dp),
          )
          .clickable(onClick = onToggleIncludeSystem)
          .padding(horizontal = 10.dp, vertical = 6.dp)
          .testTag("toggle_system_filter_button"),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Icon(
        imageVector = Icons.Rounded.FilterList,
        contentDescription = "Alternar filtro de sistema",
        tint = if (includeSystemApps) SolarOrange else EarthBrightEmerald,
        modifier = Modifier.size(18.dp),
      )
      Text(
        text = if (includeSystemApps) "Todos" else "Usuário",
        fontFamily = FontFamily.Monospace,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        color = if (includeSystemApps) SolarOrange else EarthBrightEmerald,
      )
    }
  }
}

@Composable
private fun EclipseTabBar(
  selectedTab: MainTab,
  installedCount: Int,
  excludedCount: Int,
  onSelectTab: (MainTab) -> Unit,
) {
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(14.dp))
        .background(TranslucentCardSurface)
        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp))
        .padding(4.dp),
    horizontalArrangement = Arrangement.spacedBy(6.dp),
  ) {
    TabButton(
      title = "APPS INSTALADOS ($installedCount)",
      selected = selectedTab == MainTab.INSTALLED,
      accentColor = SolarOrange,
      onClick = { onSelectTab(MainTab.INSTALLED) },
      modifier = Modifier.weight(1f).testTag("tab_installed_apps"),
    )
    TabButton(
      title = "APPS EXCLUÍDOS ($excludedCount)",
      selected = selectedTab == MainTab.EXCLUDED,
      accentColor = EarthEmerald,
      onClick = { onSelectTab(MainTab.EXCLUDED) },
      modifier = Modifier.weight(1f).testTag("tab_excluded_apps"),
    )
  }
}

@Composable
private fun TabButton(
  title: String,
  selected: Boolean,
  accentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier =
      modifier
        .heightIn(min = 48.dp)
        .clip(RoundedCornerShape(10.dp))
        .background(if (selected) accentColor.copy(alpha = 0.22f) else Color.Transparent)
        .border(
          width = if (selected) 1.2.dp else 0.dp,
          color = if (selected) accentColor else Color.Transparent,
          shape = RoundedCornerShape(10.dp),
        )
        .clickable(onClick = onClick)
        .padding(horizontal = 8.dp, vertical = 10.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = title,
      fontFamily = FontFamily.Default,
      fontWeight = FontWeight.ExtraBold,
      fontSize = 11.sp,
      color = if (selected) StarWhite else MutedSlate,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
      textAlign = TextAlign.Center,
    )
  }
}

@Composable
private fun EmptyStateCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  subtitle: String,
) {
  Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .clip(RoundedCornerShape(18.dp))
          .background(TranslucentCardSurface)
          .border(1.dp, LunarCyan.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
          .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = LunarCyan,
        modifier = Modifier.size(40.dp),
      )
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = StarWhite,
        textAlign = TextAlign.Center,
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = MutedSlate,
        textAlign = TextAlign.Center,
      )
    }
  }
}
