package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ui.theme.EarthBrightEmerald
import com.example.ui.theme.EarthEmerald
import com.example.ui.theme.EarthOceanBlue
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.LunarIce
import com.example.ui.theme.SolarCoreYellow
import com.example.ui.theme.SolarGold
import com.example.ui.theme.SolarOrange
import com.example.ui.theme.VoidSpaceBlack
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

private data class StarSpec(
  val xFraction: Float,
  val yFraction: Float,
  val radiusPx: Float,
  val phase: Float,
  val speed: Float,
  val tint: Color,
)

@Composable
fun CosmicBattleBackground(modifier: Modifier = Modifier) {
  val infiniteTransition = rememberInfiniteTransition(label = "cosmic_battle")

  // Continuous 0..1 cycle for beams, shockwaves, flares, and star twinkling
  val cycle by
    infiniteTransition.animateFloat(
      initialValue = 0f,
      targetValue = 1f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 3200, easing = LinearEasing),
          repeatMode = RepeatMode.Restart,
        ),
      label = "battle_cycle",
    )

  val slowOrbit by
    infiniteTransition.animateFloat(
      initialValue = 0f,
      targetValue = (2.0 * PI).toFloat(),
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 12000, easing = LinearEasing),
          repeatMode = RepeatMode.Restart,
        ),
      label = "slow_orbit",
    )

  val stars = remember {
    val rng = Random(4209)
    val tints =
      listOf(
        Color.White,
        Color(0xFFE0F7FA),
        Color(0xFFFFF3E0),
        Color(0xFFA7F3D0),
      )
    List(95) {
      StarSpec(
        xFraction = rng.nextFloat(),
        yFraction = rng.nextFloat(),
        radiusPx = 1.1f + rng.nextFloat() * 2.4f,
        phase = rng.nextFloat() * (2f * PI.toFloat()),
        speed = 1f + rng.nextFloat() * 2.5f,
        tint = tints[rng.nextInt(tints.size)],
      )
    }
  }

  Canvas(modifier = modifier.fillMaxSize().background(VoidSpaceBlack)) {
    val w = size.width
    val h = size.height
    if (w <= 0f || h <= 0f) return@Canvas

    val minDim = min(w, h)
    val battleY = h * 0.30f
    val sunCenter = Offset(w * 0.13f, battleY)
    val moonCenter = Offset(w * 0.87f, battleY)
    val earthCenter = Offset(w * 0.50f, battleY)

    val sunRadius = (minDim * 0.095f).coerceIn(24f, 68f)
    val moonRadius = (minDim * 0.082f).coerceIn(20f, 58f)
    val earthRadius = (minDim * 0.088f).coerceIn(22f, 62f)
    val shieldRadius = earthRadius * 1.58f

    // 1. Subtle deep nebula glow behind Sun & Moon
    drawCircle(
      brush =
        Brush.radialGradient(
          colors = listOf(SolarOrange.copy(alpha = 0.22f), Color.Transparent),
          center = sunCenter,
          radius = sunRadius * 4.2f,
        ),
      radius = sunRadius * 4.2f,
      center = sunCenter,
    )
    drawCircle(
      brush =
        Brush.radialGradient(
          colors = listOf(LunarCyan.copy(alpha = 0.20f), Color.Transparent),
          center = moonCenter,
          radius = moonRadius * 4.2f,
        ),
      radius = moonRadius * 4.2f,
      center = moonCenter,
    )

    // 2. Twinkling Starfield
    val timeAngle = slowOrbit * 2f
    stars.forEach { star ->
      val alpha = 0.22f + 0.78f * ((sin(timeAngle * star.speed + star.phase) + 1f) * 0.5f)
      val pos = Offset(star.xFraction * w, star.yFraction * h)
      drawCircle(
        color = star.tint.copy(alpha = alpha.coerceIn(0.1f, 1f)),
        radius = star.radiusPx,
        center = pos,
      )
    }

    // 3. Solar Plasma Beams (Sun -> Earth's Left Shield)
    val leftShieldEdge = Offset(earthCenter.x - shieldRadius, earthCenter.y)
    drawEnergyBeams(
      origin = Offset(sunCenter.x + sunRadius * 0.8f, sunCenter.y),
      target = leftShieldEdge,
      primaryColor = SolarOrange,
      coreColor = SolarCoreYellow,
      cycle = cycle,
      directionSign = 1f,
      amplitude = minDim * 0.025f,
    )

    // 4. Lunar Cyan Energy Beams (Moon -> Earth's Right Shield)
    val rightShieldEdge = Offset(earthCenter.x + shieldRadius, earthCenter.y)
    drawEnergyBeams(
      origin = Offset(moonCenter.x - moonRadius * 0.8f, moonCenter.y),
      target = rightShieldEdge,
      primaryColor = LunarCyan,
      coreColor = LunarIce,
      cycle = (cycle + 0.5f) % 1f,
      directionSign = -1f,
      amplitude = minDim * 0.025f,
    )

    // 5. Blazing Sun (Left)
    drawBlazingSun(sunCenter, sunRadius, slowOrbit, cycle)

    // 6. Luminous Moon (Right)
    drawLuminousMoon(moonCenter, moonRadius, slowOrbit, cycle)

    // 7. Earth + Emerald Shield + Continuous Shockwaves (Center)
    drawShieldedEarth(
      center = earthCenter,
      earthRadius = earthRadius,
      shieldRadius = shieldRadius,
      cycle = cycle,
      slowOrbit = slowOrbit,
    )
  }
}

private fun DrawScope.drawBlazingSun(
  center: Offset,
  radius: Float,
  slowOrbit: Float,
  cycle: Float,
) {
  val pulse = 1f + 0.08f * sin(cycle * 2f * PI.toFloat())
  drawCircle(
    brush =
      Brush.radialGradient(
        colors =
          listOf(
            SolarOrange.copy(alpha = 0.65f),
            SolarGold.copy(alpha = 0.25f),
            Color.Transparent,
          ),
        center = center,
        radius = radius * 2.3f * pulse,
      ),
    radius = radius * 2.3f * pulse,
    center = center,
  )

  // Rotating solar flame rays
  val rayCount = 12
  for (i in 0 until rayCount) {
    val angle = slowOrbit + (i * (2f * PI.toFloat() / rayCount))
    val inner =
      Offset(center.x + cos(angle) * radius * 0.92f, center.y + sin(angle) * radius * 0.92f)
    val rayLen = radius * (1.28f + 0.22f * sin(cycle * 2f * PI.toFloat() + i))
    val outer = Offset(center.x + cos(angle) * rayLen, center.y + sin(angle) * rayLen)
    drawLine(
      color = if (i % 2 == 0) SolarOrange.copy(alpha = 0.85f) else SolarGold.copy(alpha = 0.85f),
      start = inner,
      end = outer,
      strokeWidth = radius * 0.14f,
      cap = StrokeCap.Round,
    )
  }

  // Sun core disc
  drawCircle(
    brush =
      Brush.radialGradient(
        colors = listOf(SolarCoreYellow, SolarGold, SolarOrange),
        center = center,
        radius = radius,
      ),
    radius = radius,
    center = center,
  )
}

private fun DrawScope.drawLuminousMoon(
  center: Offset,
  radius: Float,
  slowOrbit: Float,
  cycle: Float,
) {
  val pulse = 1f + 0.07f * cos(cycle * 2f * PI.toFloat())
  drawCircle(
    brush =
      Brush.radialGradient(
        colors =
          listOf(
            LunarCyan.copy(alpha = 0.55f),
            LunarCyan.copy(alpha = 0.16f),
            Color.Transparent,
          ),
        center = center,
        radius = radius * 2.2f * pulse,
      ),
    radius = radius * 2.2f * pulse,
    center = center,
  )

  // Orbiting lunar energy arcs
  for (i in 0..2) {
    val startDeg = Math.toDegrees(slowOrbit.toDouble()).toFloat() + i * 120f
    drawArc(
      color = LunarCyan.copy(alpha = 0.55f),
      startAngle = startDeg,
      sweepAngle = 55f,
      useCenter = false,
      topLeft = Offset(center.x - radius * 1.28f, center.y - radius * 1.28f),
      size = Size(radius * 2.56f, radius * 2.56f),
      style = Stroke(width = 3f, cap = StrokeCap.Round),
    )
  }

  // Moon disc
  drawCircle(
    brush =
      Brush.radialGradient(
        colors = listOf(LunarIce, LunarCyan, Color(0xFF0284C7)),
        center = Offset(center.x - radius * 0.2f, center.y - radius * 0.2f),
        radius = radius * 1.2f,
      ),
    radius = radius,
    center = center,
  )

  // Subtle lunar craters
  drawCircle(
    color = Color(0x33041E42),
    radius = radius * 0.22f,
    center = Offset(center.x - radius * 0.28f, center.y - radius * 0.15f),
  )
  drawCircle(
    color = Color(0x2B041E42),
    radius = radius * 0.15f,
    center = Offset(center.x + radius * 0.22f, center.y + radius * 0.26f),
  )
  drawCircle(
    color = Color(0x24041E42),
    radius = radius * 0.12f,
    center = Offset(center.x + radius * 0.14f, center.y - radius * 0.34f),
  )
}

private fun DrawScope.drawEnergyBeams(
  origin: Offset,
  target: Offset,
  primaryColor: Color,
  coreColor: Color,
  cycle: Float,
  directionSign: Float,
  amplitude: Float,
) {
  val totalDx = target.x - origin.x
  val segments = 16

  // Main pulsing wave beam
  val wavePath = Path()
  wavePath.moveTo(origin.x, origin.y)
  for (step in 1..segments) {
    val t = step.toFloat() / segments
    val x = origin.x + totalDx * t
    val envelope = sin(t * PI.toFloat())
    val y =
      origin.y +
        sin(t * 10f - cycle * 4f * PI.toFloat() * directionSign) * amplitude * envelope
    wavePath.lineTo(x, y)
  }

  drawPath(
    path = wavePath,
    color = primaryColor.copy(alpha = 0.42f),
    style = Stroke(width = 12f, cap = StrokeCap.Round),
  )
  drawPath(
    path = wavePath,
    color = coreColor.copy(alpha = 0.88f),
    style = Stroke(width = 4f, cap = StrokeCap.Round),
  )

  // Traveling plasma projectiles hitting the shield
  for (p in 0..2) {
    val progress = (cycle + p / 3f) % 1f
    val px = origin.x + totalDx * progress
    val py = origin.y + sin(progress * 6f) * (amplitude * 0.4f)
    drawCircle(
      color = primaryColor.copy(alpha = 0.65f),
      radius = 8f,
      center = Offset(px, py),
    )
    drawCircle(
      color = coreColor,
      radius = 3.5f,
      center = Offset(px, py),
    )
  }
}

private fun DrawScope.drawShieldedEarth(
  center: Offset,
  earthRadius: Float,
  shieldRadius: Float,
  cycle: Float,
  slowOrbit: Float,
) {
  // 1. Continuous expanding shockwave rings from the Emerald Shield
  for (waveIndex in 0..2) {
    val waveProgress = (cycle + waveIndex / 3f) % 1f
    val ringRadius = shieldRadius + waveProgress * (shieldRadius * 0.95f)
    val ringAlpha = (1f - waveProgress) * 0.52f
    drawCircle(
      color = EarthEmerald.copy(alpha = ringAlpha),
      radius = ringRadius,
      center = center,
      style = Stroke(width = 3.5f * (1f - waveProgress * 0.5f)),
    )
  }

  // 2. Emerald Shield Dome Fill & Outer Ring
  drawCircle(
    brush =
      Brush.radialGradient(
        colors =
          listOf(
            Color.Transparent,
            EarthEmerald.copy(alpha = 0.14f),
            EarthBrightEmerald.copy(alpha = 0.34f),
          ),
        center = center,
        radius = shieldRadius,
      ),
    radius = shieldRadius,
    center = center,
  )

  drawCircle(
    color = EarthEmerald.copy(alpha = 0.85f),
    radius = shieldRadius,
    center = center,
    style = Stroke(width = 3.5f),
  )

  // Rotating shield energy segments
  for (seg in 0..5) {
    val startAngle = Math.toDegrees(slowOrbit.toDouble()).toFloat() + seg * 60f
    drawArc(
      color = EarthBrightEmerald.copy(alpha = 0.72f),
      startAngle = startAngle,
      sweepAngle = 32f,
      useCenter = false,
      topLeft = Offset(center.x - shieldRadius * 1.07f, center.y - shieldRadius * 1.07f),
      size = Size(shieldRadius * 2.14f, shieldRadius * 2.14f),
      style = Stroke(width = 2.5f, cap = StrokeCap.Round),
    )
  }

  // Impact flare arcs on left (blocking Solar plasma) and right (blocking Lunar beam)
  val flashAlpha = 0.55f + 0.45f * sin(cycle * 6f * PI.toFloat())
  drawArc(
    color = SolarOrange.copy(alpha = flashAlpha),
    startAngle = 142f,
    sweepAngle = 76f,
    useCenter = false,
    topLeft = Offset(center.x - shieldRadius * 1.03f, center.y - shieldRadius * 1.03f),
    size = Size(shieldRadius * 2.06f, shieldRadius * 2.06f),
    style = Stroke(width = 5f, cap = StrokeCap.Round),
  )
  drawArc(
    color = LunarCyan.copy(alpha = flashAlpha),
    startAngle = -38f,
    sweepAngle = 76f,
    useCenter = false,
    topLeft = Offset(center.x - shieldRadius * 1.03f, center.y - shieldRadius * 1.03f),
    size = Size(shieldRadius * 2.06f, shieldRadius * 2.06f),
    style = Stroke(width = 5f, cap = StrokeCap.Round),
  )

  // 3. Planet Earth Core
  drawCircle(
    brush =
      Brush.radialGradient(
        colors = listOf(Color(0xFF38BDF8), EarthOceanBlue, Color(0xFF0F172A)),
        center = Offset(center.x - earthRadius * 0.25f, center.y - earthRadius * 0.25f),
        radius = earthRadius * 1.35f,
      ),
    radius = earthRadius,
    center = center,
  )

  // Continents drifting slightly with slowOrbit
  val driftX = sin(slowOrbit) * (earthRadius * 0.18f)
  drawCircle(
    color = EarthEmerald.copy(alpha = 0.92f),
    radius = earthRadius * 0.34f,
    center = Offset(center.x - earthRadius * 0.22f + driftX, center.y - earthRadius * 0.18f),
  )
  drawCircle(
    color = EarthBrightEmerald.copy(alpha = 0.88f),
    radius = earthRadius * 0.28f,
    center = Offset(center.x + earthRadius * 0.26f + driftX * 0.6f, center.y + earthRadius * 0.20f),
  )
  drawCircle(
    color = EarthEmerald.copy(alpha = 0.80f),
    radius = earthRadius * 0.18f,
    center = Offset(center.x - earthRadius * 0.30f + driftX * 0.5f, center.y + earthRadius * 0.30f),
  )

  // Earth atmospheric rim
  drawCircle(
    color = Color(0xAA38BDF8),
    radius = earthRadius,
    center = center,
    style = Stroke(width = 2f),
  )
}
