package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VoidSpaceBlack = Color(0xFF04050C)
val TranslucentCardSurface = Color(0xCC0A0E1A)
val TranslucentElevatedSurface = Color(0xD9101729)

val SolarOrange = Color(0xFFFF6B00)
val SolarGold = Color(0xFFFFB800)
val SolarCoreYellow = Color(0xFFFFE066)

val LunarCyan = Color(0xFF00E5FF)
val LunarIce = Color(0xFF9AF4FF)

val EarthEmerald = Color(0xFF10B981)
val EarthBrightEmerald = Color(0xFF34D399)
val EarthOceanBlue = Color(0xFF1D4ED8)

val DangerCrimson = Color(0xFFDC2626)
val DangerBrightRed = Color(0xFFFF3B30)
val DangerDarkSurface = Color(0xE62A080C)

val StarWhite = Color(0xFFF8FAFC)
val MutedSlate = Color(0xFF94A3B8)
val SubtleBorder = Color(0x4D00E5FF)
