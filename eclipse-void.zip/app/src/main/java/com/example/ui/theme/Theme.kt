package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val EclipseVoidColorScheme =
  darkColorScheme(
    primary = LunarCyan,
    onPrimary = VoidSpaceBlack,
    primaryContainer = TranslucentElevatedSurface,
    onPrimaryContainer = LunarIce,
    secondary = SolarOrange,
    onSecondary = VoidSpaceBlack,
    secondaryContainer = TranslucentElevatedSurface,
    onSecondaryContainer = SolarGold,
    tertiary = EarthEmerald,
    onTertiary = VoidSpaceBlack,
    tertiaryContainer = TranslucentElevatedSurface,
    onTertiaryContainer = EarthBrightEmerald,
    background = VoidSpaceBlack,
    onBackground = StarWhite,
    surface = TranslucentCardSurface,
    onSurface = StarWhite,
    surfaceVariant = TranslucentElevatedSurface,
    onSurfaceVariant = MutedSlate,
    outline = SubtleBorder,
    error = DangerBrightRed,
    onError = StarWhite,
    errorContainer = DangerDarkSurface,
    onErrorContainer = StarWhite,
  )

private val EclipseVoidShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
  )

@Composable
fun EclipseVoidTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = EclipseVoidColorScheme,
    typography = EclipseTypography,
    shapes = EclipseVoidShapes,
    content = content,
  )
}
