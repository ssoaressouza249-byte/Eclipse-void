package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.GppBad
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppStorageRepository
import com.example.data.ExcludedAppItem
import com.example.data.InstalledAppItem
import com.example.ui.theme.DangerBrightRed
import com.example.ui.theme.DangerCrimson
import com.example.ui.theme.DangerDarkSurface
import com.example.ui.theme.EarthBrightEmerald
import com.example.ui.theme.EarthEmerald
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.SolarGold
import com.example.ui.theme.SolarOrange
import com.example.ui.theme.StarWhite
import com.example.ui.theme.TranslucentCardSurface
import com.example.ui.theme.VoidSpaceBlack

@Composable
fun InstalledAppCard(
  app: InstalledAppItem,
  isBusy: Boolean,
  anyBusy: Boolean,
  onExcludeClick: () -> Unit,
) {
  val borderBrush =
    if (app.isSystemOrProtected) {
      Brush.horizontalGradient(listOf(DangerCrimson.copy(alpha = 0.85f), SolarOrange.copy(alpha = 0.7f)))
    } else {
      Brush.horizontalGradient(listOf(SolarOrange.copy(alpha = 0.7f), LunarCyan.copy(alpha = 0.75f)))
    }

  Column(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(18.dp))
        .background(TranslucentCardSurface)
        .border(1.2.dp, borderBrush, RoundedCornerShape(18.dp))
        .padding(14.dp)
        .testTag("installed_app_card_${app.packageName}"),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      AppIconBadge(drawable = app.icon, contentDescription = app.appName)

      Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Text(
            text = app.appName,
            style = MaterialTheme.typography.titleMedium,
            color = StarWhite,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false),
          )
          if (app.isSystemOrProtected) {
            Icon(
              imageVector = Icons.Rounded.Shield,
              contentDescription = "App protegido",
              tint = DangerBrightRed,
              modifier = Modifier.size(16.dp),
            )
          }
        }

        Text(
          text = app.packageName,
          style = MaterialTheme.typography.bodySmall,
          color = MutedSlate,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Box(
        modifier =
          Modifier.background(Color(0x3300E5FF), RoundedCornerShape(10.dp))
            .border(1.dp, LunarCyan.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
      ) {
        Text(
          text = AppStorageRepository.formatSize(app.sizeBytes),
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 12.sp,
          color = LunarCyan,
        )
      }
    }

    Button(
      onClick = onExcludeClick,
      enabled = !anyBusy,
      colors =
        ButtonDefaults.buttonColors(
          containerColor = if (app.isSystemOrProtected) DangerCrimson else SolarOrange,
          contentColor = Color.White,
          disabledContainerColor = Color(0x44334155),
          disabledContentColor = MutedSlate,
        ),
      shape = RoundedCornerShape(12.dp),
      modifier =
        Modifier.fillMaxWidth()
          .heightIn(min = 48.dp)
          .testTag("exclude_app_button_${app.packageName}"),
    ) {
      if (isBusy) {
        CircularProgressIndicator(
          modifier = Modifier.size(18.dp),
          strokeWidth = 2.dp,
          color = Color.White,
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "LIBERANDO ESPAÇO...",
          style = MaterialTheme.typography.labelLarge,
        )
      } else {
        Icon(
          imageVector = Icons.Rounded.DeleteSweep,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "EXCLUIR APP (LIBERAR ESPAÇO)",
          style = MaterialTheme.typography.labelLarge,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}

@Composable
fun ExcludedAppCard(
  app: ExcludedAppItem,
  isBusy: Boolean,
  anyBusy: Boolean,
  onRestoreClick: () -> Unit,
) {
  val borderBrush =
    Brush.horizontalGradient(
      listOf(EarthEmerald.copy(alpha = 0.85f), LunarCyan.copy(alpha = 0.7f))
    )

  Column(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(18.dp))
        .background(TranslucentCardSurface)
        .border(1.2.dp, borderBrush, RoundedCornerShape(18.dp))
        .padding(14.dp)
        .testTag("excluded_app_card_${app.packageName}"),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Box(
        modifier =
          Modifier.size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x3310B981))
            .border(1.dp, EarthEmerald.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Rounded.Android,
          contentDescription = app.appName,
          tint = EarthBrightEmerald,
          modifier = Modifier.size(26.dp),
        )
      }

      Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
          text = app.appName,
          style = MaterialTheme.typography.titleMedium,
          color = StarWhite,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = app.packageName,
          style = MaterialTheme.typography.bodySmall,
          color = MutedSlate,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Box(
        modifier =
          Modifier.background(Color(0x3310B981), RoundedCornerShape(10.dp))
            .border(1.dp, EarthEmerald.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
      ) {
        Text(
          text = AppStorageRepository.formatSize(app.sizeBytes),
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 12.sp,
          color = EarthBrightEmerald,
        )
      }
    }

    Button(
      onClick = onRestoreClick,
      enabled = !anyBusy,
      colors =
        ButtonDefaults.buttonColors(
          containerColor = EarthEmerald,
          contentColor = VoidSpaceBlack,
          disabledContainerColor = Color(0x44334155),
          disabledContentColor = MutedSlate,
        ),
      shape = RoundedCornerShape(12.dp),
      modifier =
        Modifier.fillMaxWidth()
          .heightIn(min = 48.dp)
          .testTag("restore_app_button_${app.packageName}"),
    ) {
      if (isBusy) {
        CircularProgressIndicator(
          modifier = Modifier.size(18.dp),
          strokeWidth = 2.dp,
          color = VoidSpaceBlack,
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = "RESTAURANDO...", style = MaterialTheme.typography.labelLarge)
      } else {
        Icon(
          imageVector = Icons.Rounded.Restore,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = "VOLTAR APP", style = MaterialTheme.typography.labelLarge)
      }
    }
  }
}

@Composable
fun SystemAppBlockedModal(
  appLabel: String?,
  message: String,
  onDismiss: () -> Unit,
) {
  // In-hierarchy overlay modal so it works identically in Activity AND Floating Service Window
  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(Color(0xB804050C))
        .clickable(onClick = onDismiss)
        .padding(20.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .clip(RoundedCornerShape(22.dp))
          .background(DangerDarkSurface)
          .border(2.dp, DangerBrightRed, RoundedCornerShape(22.dp))
          .clickable(enabled = false, onClick = {})
          .padding(20.dp)
          .testTag("system_app_blocked_dialog"),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Box(
        modifier =
          Modifier.size(52.dp)
            .clip(CircleShape)
            .background(Color(0x33FF3B30))
            .border(1.5.dp, DangerBrightRed, CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Rounded.GppBad,
          contentDescription = "Bloqueio de app do sistema",
          tint = DangerBrightRed,
          modifier = Modifier.size(30.dp),
        )
      }

      Text(
        text = "AÇÃO BLOQUEADA",
        color = DangerBrightRed,
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 18.sp,
        textAlign = TextAlign.Center,
      )

      if (!appLabel.isNullOrBlank()) {
        Text(
          text = appLabel,
          color = SolarGold,
          fontFamily = FontFamily.Monospace,
          fontSize = 12.sp,
          textAlign = TextAlign.Center,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Text(
        text = message,
        color = Color.White,
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 22.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.testTag("system_app_blocked_message"),
      )

      Spacer(modifier = Modifier.height(4.dp))

      Button(
        onClick = onDismiss,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = DangerCrimson,
            contentColor = Color.White,
          ),
        shape = RoundedCornerShape(12.dp),
        modifier =
          Modifier.fillMaxWidth()
            .heightIn(min = 48.dp)
            .testTag("system_app_blocked_dismiss_button"),
      ) {
        Text(text = "FECHAR AVISO", style = MaterialTheme.typography.labelLarge)
      }
    }
  }
}

@Composable
private fun AppIconBadge(drawable: Drawable?, contentDescription: String) {
  val bitmap: ImageBitmap? =
    remember(drawable) {
      drawable?.let {
        runCatching { drawableToBitmap(it).asImageBitmap() }.getOrNull()
      }
    }

  Box(
    modifier =
      Modifier.size(44.dp)
        .clip(RoundedCornerShape(12.dp))
        .background(Color(0x4404050C))
        .border(1.dp, Color(0x4DFFFFFF), RoundedCornerShape(12.dp)),
    contentAlignment = Alignment.Center,
  ) {
    if (bitmap != null) {
      Image(
        bitmap = bitmap,
        contentDescription = contentDescription,
        modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)),
      )
    } else {
      Icon(
        imageVector = Icons.Rounded.Android,
        contentDescription = contentDescription,
        tint = LunarCyan,
        modifier = Modifier.size(26.dp),
      )
    }
  }
}

private fun drawableToBitmap(drawable: Drawable): Bitmap {
  if (drawable is BitmapDrawable && drawable.bitmap != null) {
    return drawable.bitmap
  }
  val width = drawable.intrinsicWidth.takeIf { it > 0 } ?: 96
  val height = drawable.intrinsicHeight.takeIf { it > 0 } ?: 96
  val bitmap = Bitmap.createBitmap(width.coerceAtMost(192), height.coerceAtMost(192), Bitmap.Config.ARGB_8888)
  val canvas = Canvas(bitmap)
  drawable.setBounds(0, 0, canvas.width, canvas.height)
  drawable.draw(canvas)
  return bitmap
}
