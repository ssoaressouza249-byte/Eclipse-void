package com.example

import android.content.Context
import android.content.pm.ApplicationInfo
import androidx.test.core.app.ApplicationProvider
import com.example.data.ExcludedAppItem
import com.example.data.ExcludedAppsRepository
import com.example.security.SecurityGuard
import com.example.security.SystemAppGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app identity and security guard match ECLIPSE VOID`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("ECLIPSE VOID", context.getString(R.string.app_name))
    val integrity = SecurityGuard.verifyIntegrity(context)
    assertTrue(integrity.isOriginal)
    assertEquals("com.raylan.eclipsevoid", integrity.detectedPackage)
  }

  @Test
  fun `system app guard blocks critical packages and system flags`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    val blockedPrefixes =
      listOf(
        "com.android.settings",
        "android",
        "com.google.android.gms",
        "com.sec.android.app.launcher",
        "com.miui.securitycenter",
        "com.xiaomi.mipicks",
        "moe.shizuku.privileged.api",
        "com.raylan.eclipsevoid",
      )

    blockedPrefixes.forEach { pkg ->
      assertTrue("Expected $pkg to be protected", SystemAppGuard.isCriticalPackageName(pkg))
      val verification = SystemAppGuard.verifyBeforeExecution(context, pkg, pkg)
      assertFalse(verification.allowed)
      assertEquals(SystemAppGuard.SYSTEM_APP_BLOCKED_MESSAGE, verification.blockReasonMessage)
    }

    val sysAppInfo = ApplicationInfo().apply {
      packageName = "com.some.vendor.app"
      flags = ApplicationInfo.FLAG_SYSTEM
    }
    assertFalse(SystemAppGuard.isUserDownloadedApp(sysAppInfo))

    val userAppInfo = ApplicationInfo().apply {
      packageName = "com.example.usergame"
      flags = 0
    }
    assertTrue(SystemAppGuard.isUserDownloadedApp(userAppInfo))
  }

  @Test
  fun `excluded apps repository persists and removes items in SharedPreferences`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = ExcludedAppsRepository(context)
    val item =
      ExcludedAppItem(
        packageName = "com.example.heavygame",
        appName = "Heavy Game",
        sizeBytes = 250_000_000L,
        excludedAtMillis = 123456789L,
      )

    repo.addOrUpdate(item)
    val stored = repo.getAll()
    assertEquals(1, stored.size)
    assertEquals("com.example.heavygame", stored.first().packageName)

    repo.remove("com.example.heavygame")
    assertTrue(repo.getAll().isEmpty())
  }
}
